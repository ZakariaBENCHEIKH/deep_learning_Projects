# 第二組 glasses > 2022-03-26 3:44pm
https://universe.roboflow.com/allen-73x0p/----glasses

Provided by a Roboflow user
License: CC BY 4.0

