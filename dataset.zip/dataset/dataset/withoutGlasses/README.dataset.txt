# face mask > 2022-10-01 12:05am
https://universe.roboflow.com/amsyar/face-mask-phwot

Provided by a Roboflow user
License: CC BY 4.0

